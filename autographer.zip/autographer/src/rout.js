import React from 'react'
import {Routes,Route} from 'react-router-dom'
import Signup from './signup'
import Login from './login'
import NetworkDiagram from './NetworkDiagram'
import MainWindow from './MainWindow'
const Rout = () => {
  return (
    <>
   <Routes>
<Route path='/Signup'element={<Signup/>}></Route>
<Route path='/login' element={<Login/>}></Route>
<Route path='/NetworkDiagram' element={<NetworkDiagram/>}></Route>
<Route path='/' element={<MainWindow/>}></Route>







    </Routes>
    
    
    
    </>
  )
}

export default Rout