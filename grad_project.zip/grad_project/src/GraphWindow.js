import classes from './GraphWindow.module.css';
import NetworkDiagram from './NetworkDiagram';
function GraphWindow(props) {

  
  return (
    <div>

    <div className={classes.TopBar}>
      <header> <title> AutoGrapher</title></header>
     
     
        <img src='logo.png' alt='Logo'style={{position:'absolute', height:'90px', width:'90px', top:'0', left:'0',userSelect: "none",pointerEvents:"none"}} ></img> 
     <div style={{marginLeft:'60px'}} >

     
        
        
        <b className={classes.text} style={{ userSelect: "none", pointerEvents: "none" }}>   AutoGrapher</b>  
     
    
     
        <a className={classes.TextButton} style={{ userSelect: "none"}} onClick={props.onChangeWindow}>settings</a>
        <a className={classes.TextButton2} style={{ userSelect: "none"}}> Export</a>
        <a className={classes.TextButton2} style={{ userSelect: "none"}}> import</a>
        <a className={classes.TextButton2} style={{ userSelect: "none"}}>Help </a>
        <button className={classes.button} style={{ userSelect: "none"}}>Login </button>
      
      </div>
      </div>
      <div className={classes.body}>

      <div className={classes.TopBar2}>
        <button className={classes.operationsButtons} style={{ userSelect: "none"}} onClick={props.onChangeWindow}> Graph</button>
        <button className={classes.operationsButtons} style={{ userSelect: "none"}}> Add vertex</button>
        <button className={classes.operationsButtons} style={{ userSelect: "none"}}> Algorithms</button>
       
        
      </div>
            {/* <div style={{marginTop:'150px'}}>  
             <NetworkDiagram/>
            </div> */}
      </div>
      
    
      
    </div>
  );
}

export default GraphWindow;
