/* eslint-disable jsx-a11y/anchor-is-valid */
import classes from "./App.module.css";
import { Link } from "react-router-dom";
import Popup from "reactjs-popup";
import { useNavigate } from "react-router-dom";
import React, { useState, useEffect } from "react";
import { auth } from "./firebaseConfig";
import logo from "./logo.png";
import img from "./image.png";
import img2 from "./Landing_Page-removebg-preview.png";

function MainWindow(props) {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setIsLoggedIn(!!user);
    });
    return () => unsubscribe();
  }, []);

  const handleLogout = () => {
    auth
      .signOut()
      .then(() => {
        setIsLoggedIn(false);
        alert("Logged out successfully");
        // navigate("/login");
      })
      .catch((error) => {
        console.error("Error logging out:", error);
      });
  };

  // Handle file selection and navigate to NetworkDiagram with selected file

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Navigate to NetworkDiagram with file and a flag to indicate processing
      navigate("/NetworkDiagram", { state: { file, processFile: true } });
    }
  };

  const resetGraph = async (graphType) => {
    try {
      const response = await fetch("/reset-graph", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ graphType }),
      });

      const data = await response.json();
      console.log("Graph reset successful:", data.message);
    } catch (error) {
      console.error("Failed to reset the graph:", error);
    }
  };

  // Handle graph type selection
  const handleGraphTypeSelect = (graphType) => {
    resetGraph(graphType);
    navigate(`/NetworkDiagram?type=${graphType}`);
  };

  return (
    <div>
      <div className={classes.TopBar}>
        <header>
          <title>AutoGrapher</title>
        </header>
        <div>
          <img
            src={logo}
            alt="Logo"
            style={{
              // opacity:"0.3",
              position: "absolute",
              height: "10vh",
              width: "10vh",
              top: "0",
              left: "0",
              userSelect: "none",
              pointerEvents: "none",
            }}
          />
          <b
            className={classes.text}
            style={{ userSelect: "none", pointerEvents: "none" }}
          >
            AutoGrapher
          </b>

          <Popup
            trigger={
              <a className={classes.TextButton} style={{ userSelect: "none" }}>
                New Graph
              </a>
            }
            modal
            nested
            contentStyle={{ position: "absolute", top: "15%", left: "25%" }}
          >
            {(close) => (
              <div className={classes.popup} style={{ zIndex: "1001" }}>
                <div className="content" style={{ fontSize: "3.5vh" }}>
                  Do you want directed or undirected graph?
                </div>
                <div>
                  <a
                    className={classes.PopupText}
                    onClick={() => handleGraphTypeSelect("directed")}
                  >
                    directed
                  </a>
                  <a
                    className={classes.PopupText}
                    style={{ marginLeft: "24vw" }}
                    onClick={() => handleGraphTypeSelect("undirected")}
                  >
                    undirected
                  </a>
                </div>
              </div>
            )}
          </Popup>
          <a className={classes.TextButton2} style={{ userSelect: "none" }}>
            <label>
              Import
              <input
                type="file"
                style={{ display: "none" }}
                onChange={handleFileChange}
              />
            </label>
          </a>

          <a style={{ userSelect: "none", textDecoration: "none" }}>
            <Link
              to="http://autograph.rf.gd"
              className={classes.TextButton2}
              style={{ userSelect: "none", textDecoration: "none" }}
            >
              Help
            </Link>
          </a>

          {isLoggedIn ? (
            <button
              className={classes.button}
              onClick={handleLogout}
              style={{ userSelect: "none" }}
            >
              Logout
            </button>
          ) : (
            <Link to="./login">
              <button className={classes.button} style={{ userSelect: "none" }}>
                Login
              </button>
            </Link>
          )}
        </div>
      </div>
      <div className={classes.body}>
        <div
          className={classes.images}
          style={{ userSelect: "none", pointerEvents: "none" }}
        >
          <p
            style={{
              position: "absolute",
              fontSize: "7.5vh",
              marginTop: "20vh",
              zIndex: "999",
              marginLeft: "1vw",
            }}
          >
            {" "}
            The intuitive network design tool
          </p>
          <p
            style={{
              position: "absolute",
              fontSize: "11.5vh",
              marginTop: "30vh",
              fontWeight: "bold",
              zIndex: "999",
              marginLeft: "1vw",
            }}
          >
            {" "}
            AutoGrapher
          </p>
          <p
            style={{
              position: "absolute",
              fontSize: "3.5vh",
              marginTop: "50vh",
              marginLeft: "5vw",
              zIndex: "999",
              background: "linear-gradient(to right, purple, pink)",
              WebkitBackgroundClip: "text", // Needed for Safari and older Chrome/Firefox
              backgroundClip: "text",
              color: "transparent", // Ensures text is transparent so the gradient shows through
              WebkitTextFillColor: "transparent", // Specifically for Webkit browsers to ensure text fill is transparent
            }}
          >
            create edit and visualize networks
          </p>

          <img
            alt="Main window graph"
            src={img}
            style={{
              opacity: "0.5",
              marginTop: "6vh",
              maxWidth: "36vw",
              userSelect: "none",
            }}
          />
          <img
            src={img2}
            alt="Graph"
            style={{
              marginTop: "6vh",
              // opacity:"0.9",
              // maxWidth:"38vw",
              width: "36vw",
              marginLeft: "25vw",
              zIndex: "999",
              userSelect: "none",
            }}
          />
        </div>

        <p
          style={{
            position: "fixed",
            bottom: "0",
            left: "5vw",
            width: "100%",
            fontSize: "1.8vh",
            margin: "0",
            fontFamily: "Arial",
            userSelect: "none",
          }}
        >
          ©2024 AutoGrapher
        </p>
      </div>
    </div>
  );
}

export default MainWindow;
