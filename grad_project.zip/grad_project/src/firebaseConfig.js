//import { initializeApp } from "firebase/app";
import  firebase from 'firebase/compat/app'
import 'firebase/compat/auth';
import 'firebase/compat/database'
import 'firebase/compat/firestore';
const firebaseConfig = {
  apiKey: "AIzaSyBheRLEqrvCYlfbm5ntl1eEoO_HfSdHbKo",
  authDomain: "autographer-6ab6b.firebaseapp.com",
  projectId: "autographer-6ab6b",
  storageBucket: "autographer-6ab6b.appspot.com",
  messagingSenderId: "425707902106",
  appId: "1:425707902106:web:ba0a64d2048ae8d2f6fb23"
};

const app = firebase.initializeApp(firebaseConfig);

export const db = app.firestore();
export const auth = app.auth(); // Export the authentication module

export default app;