/* eslint-disable no-unused-vars */
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { auth } from "./firebaseConfig"; // Import auth from firebaseConfig
import firebase from "firebase/compat/app"; // Import firebase
import classes from "./signup.module.css";
import logo from "./logo.png";
const Login = () => {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const user = await auth.signInWithEmailAndPassword(email, pass); // Use auth from firebaseConfig
      if (user) {
        alert("Logged in successfully");
        navigate("/NetworkDiagram"); // Redirect to homepage after successful login
      }
    } catch (error) {
      alert(error.message);
    }
  };

  const handleGoogleSignIn = async () => {
    const provider = new firebase.auth.GoogleAuthProvider(); // Import GoogleAuthProvider from firebase/auth
    try {
      const result = await auth.signInWithPopup(provider); // Use auth from firebaseConfig
      //   console.log(result.user); // You can access user information here
      alert("Google sign-in successful");
      navigate("./NetworkDiagram"); // Redirect to homepage after successful login
    } catch (error) {
      alert(error.message);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      alert("Please enter your email address to reset your password.");
      return;
    }
    try {
      await auth.sendPasswordResetEmail(email);
      alert(
        "If there is an account associated with " +
          email +
          ", a password reset email has been sent. Please check your inbox."
      );
    } catch (error) {
      alert(error.message);
    }
  };

  return (
    <div className={classes.body}>
      <div className={classes.TopBar}>
        <header>
          {" "}
          <title> AutoGrapher</title>
        </header>
        {/* <Link  to="/MainWindow.js"> */}
        <img
          src={logo}
          alt="Logo"
          onClick={() => (window.location.href = "../")}
          style={{
            position: "absolute",
            height: "10vh",
            width: "10vh",
            top: "0",
            left: "0",
            userSelect: "none",
            // pointerEvents: "none",
          }}
        />
        {/* </Link> */}
        <b
          className={classes.text}
          style={{
            userSelect: "none",
            pointerEvents: "none",
            fontSize: "3.5vh",
            color: "#555555",
          }}
        >
          {" "}
          AutoGrapher
        </b>
      </div>
      <div className={classes.main_container_signup}>
        {/* <div className='header'> */}
        <h2 style={{ fontSize: "3.7vh", color: "white" }}>Login</h2>
        {/* </div> */}

        <div className={classes.box} style={{ marginTop: "5vh" }}>
          <input
            type="text"
            value={email}
            placeholder="Email"
            style={{ fontSize: "1.5vh" }}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className={classes.box}>
          <input
            type="password"
            value={pass}
            placeholder="Password"
            style={{ fontSize: "1.5vh" }}
            onChange={(e) => setPass(e.target.value)}
          />
        </div>
        <p style={{ marginTop: "3vh", color: "white", fontSize: "2.5vh" }}>
          Don't have an account?{" "}
          <Link className={classes.text} to="/Signup">
            Create account
          </Link>
        </p>
        <p style={{ marginTop: "20px", color: "white", fontSize: "2.5vh" }}>
          Forgot password?{" "}
          <Link className={classes.text} onClick={handleForgotPassword}>
            Click here
          </Link>
        </p>
        <button
          onClick={handleLogin}
          style={{
            marginTop: "10vh",
            width: "15.5vw",
            height: "6vh",
            fontSize: "1.5vh",
          }}
        >
          Login
        </button>
        <button
          onClick={handleGoogleSignIn}
          style={{ width: "15.5vw", height: "6vh", fontSize: "1.5vh" }}
        >
          Sign in with Google
        </button>
      </div>
    </div>
  );
};

export default Login;
