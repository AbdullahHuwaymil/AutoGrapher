import React, { useState } from "react";
import classes from "./signup.module.css";
import { Link, useNavigate } from "react-router-dom";
import firebase from "./firebaseConfig";
import logo from "./logo.png";

const Signup = () => {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const navigate = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    try {
      const user = await firebase
        .auth()
        .createUserWithEmailAndPassword(email, pass);
      if (user) {
        alert("Account created successfully");
        navigate("/NetworkDiagram");
      }
    } catch (error) {
      alert(error);
    }
  };
  return (
    <div className={classes.body}>
      <div className={classes.TopBar}>
        <header>
          {" "}
          <title> AutoGrapher</title>
        </header>
        <img
          src={logo}
          alt="Logo"
          onClick={() => (window.location.href = "../")}
          style={{
            position: "absolute",
            height: "10vh",
            width: "10vh",
            top: "0",
            left: "0",
            userSelect: "none",
            // pointerEvents: "none",
          }}
        />
        <b
          className={classes.text}
          style={{
            userSelect: "none",
            pointerEvents: "none",
            fontSize: "3.5vh",
            color: "#555555",
          }}
        >
          {" "}
          AutoGrapher
        </b>
      </div>
      <div className={classes.main_container_signup}>
        <h2 style={{ fontSize: "3.7vh", color: "white" }}>signup</h2>

        <div className={classes.box} style={{ marginTop: "5vh" }}>
          <input
            type="text"
            value={email}
            style={{ fontSize: "1.5vh" }}
            placeholder="Email"
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className={classes.box}>
          <input
            type="password"
            value={pass}
            style={{ fontSize: "1.5vh" }}
            placeholder="Password"
            onChange={(e) => setPass(e.target.value)}
          />
        </div>

        <p style={{ marginTop: "3vh", color: "white", fontSize: "2.5vh" }}>
          Already have an account?{" "}
          <Link className={classes.text} to="/login">
            Login now
          </Link>
        </p>
        <button
          style={{
            marginTop: "20vh",
            width: "15.5vw",
            height: "6vh",
            fontSize: "1.5vh",
          }}
          onClick={submit}
        >
          SignUp
        </button>
      </div>
    </div>
  );
};

export default Signup;
